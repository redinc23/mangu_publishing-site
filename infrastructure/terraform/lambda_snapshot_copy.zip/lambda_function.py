import boto3
import os
from datetime import datetime, timedelta

rds_source = boto3.client('rds', region_name='us-east-1')
rds_dr = boto3.client('rds', region_name='us-west-2')
      
DB_INSTANCE = os.environ['DB_INSTANCE']
RETENTION_DAYS = int(os.environ.get('RETENTION_DAYS', '7'))

def lambda_handler(event, context):
    account_id = context.invoked_function_arn.split(':')[4]
          
    # Get latest automated snapshot
    snapshots = rds_source.describe_db_snapshots(
        DBInstanceIdentifier=DB_INSTANCE,
        SnapshotType='automated'
    )['DBSnapshots']
          
    if not snapshots:
        return {'statusCode': 404, 'body': 'No snapshots found'}
          
    latest = sorted(snapshots, key=lambda x: x['SnapshotCreateTime'])[-1]
    source_id = latest['DBSnapshotIdentifier']
    dr_id = f"{source_id}-dr-{datetime.now().strftime('%Y%m%d')}"
          
    # Check if already copied
    try:
        rds_dr.describe_db_snapshots(DBSnapshotIdentifier=dr_id)
        return {'statusCode': 200, 'body': f'Already copied: {dr_id}'}
    except rds_dr.exceptions.DBSnapshotNotFoundFault:
        pass
          
    # Copy snapshot
    source_arn = f"arn:aws:rds:us-east-1:{account_id}:snapshot:{source_id}"
    rds_dr.copy_db_snapshot(
        SourceDBSnapshotIdentifier=source_arn,
        TargetDBSnapshotIdentifier=dr_id,
        CopyTags=True,
        Tags=[
            {'Key': 'CopiedFrom', 'Value': source_id},
            {'Key': 'CopyDate', 'Value': datetime.now().strftime('%Y-%m-%d')},
            {'Key': 'Purpose', 'Value': 'DisasterRecovery'}
        ]
    )
          
    # Cleanup old snapshots
    cutoff = datetime.now() - timedelta(days=RETENTION_DAYS)
    old_snapshots = rds_dr.describe_db_snapshots(SnapshotType='manual')['DBSnapshots']
          
    for snap in old_snapshots:
        if snap['DBSnapshotIdentifier'].startswith(f'rds:{DB_INSTANCE}'):
            if snap['SnapshotCreateTime'].replace(tzinfo=None) < cutoff:
                rds_dr.delete_db_snapshot(DBSnapshotIdentifier=snap['DBSnapshotIdentifier'])
          
    return {'statusCode': 200, 'body': f'Copied: {dr_id}'}
